<?php

/**
 * Plugin Name:       character cpt
 * Description:       creates CPT character.
 * Version:           1.0
 * Requires at least: 5.2
 * Requires PHP:      7.2
 * Author:            Shahala Anjum
 * Author URI:        https://author.example.com/
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Update URI:        https://example.com/my-plugin/
 * Text Domain:       my-plugin
 * Domain Path:       /languages
 */



 /*
* Creating a function to create our CPT
*/
  
function custom_post_type() {
  
    // Set UI labels for Custom Post Type
        $labels = array(
            'name'                => _x( 'Characters', 'Post Type General Name', 'text-domain' ),
            'singular_name'       => _x( 'Character', 'Post Type Singular Name', 'text-domain' ),
            'menu_name'           => __( 'Characters', 'text-domain' ),
            'parent_item_colon'   => __( 'Parent Character', 'text-domain' ),
            'all_items'           => __( 'All Characters', 'text-domain' ),
            'view_item'           => __( 'View Character', 'text-domain' ),
            'add_new_item'        => __( 'Add New Character', 'text-domain' ),
            'add_new'             => __( 'Add New', 'text-domain' ),
            'edit_item'           => __( 'Edit Character', 'text-domain' ),
            'update_item'         => __( 'Update Character', 'text-domain' ),
            'search_items'        => __( 'Search Character', 'text-domain' ),
            'not_found'           => __( 'Not Found', 'text-domain' ),
            'not_found_in_trash'  => __( 'Not found in Trash', 'text-domain' ),
        );
          
    // Set other options for Custom Post Type
          
        $args = array(
            'label'               => __( 'Characters', 'text-domain' ),
            'description'         => __( 'Character news and reviews', 'text-domain' ),
            'labels'              => $labels, 
            'supports'            => array( 'title', 'editor', 'excerpt', 'author', 'thumbnail', 'comments', 'revisions', 'custom-fields', ), 
            'taxonomies'          => array( 'genres' ),
             
            'hierarchical'        => false,
            'public'              => true,
            'show_ui'             => true,
            'show_in_menu'        => true,
            'show_in_nav_menus'   => true,
            'show_in_admin_bar'   => true,
            'menu_position'       => 5,
            'can_export'          => true,
            'has_archive'         => true,
            'exclude_from_search' => false,
            'publicly_queryable'  => true,
            'capability_type'     => 'post',
            'show_in_rest' => true,
      
        ); 
        register_post_type( 'Characters', $args );
      
    } 
    add_action( 'init', 'custom_post_type', 0 );


//custom fields

    function character_add_meta_box() {
        //this will add the metabox for the post type
        $screens = array( 'Characters' );
        
        foreach ( $screens as $screen ) {
        
            add_meta_box(
                'member_sectionid',
                __( 'Custom Details', 'text-domain' ),
                'member_meta_box_callback',
                $screen
            );
         }
        }
        add_action( 'add_meta_boxes', 'character_add_meta_box' );
        
        /**
         * Prints the box content.
         *
         * @param WP_Post $post The object for the current post/page.
         */
        function member_meta_box_callback( $post ) {
        
        // Add a nonce field so we can check for it later.
        wp_nonce_field( 'character_save_meta_box_data', 'character_meta_box_nonce' );
        
        /*
         * Use get_post_meta() to retrieve an existing value
         * from the database and use the value for the form.
         */
        $value = get_post_meta( $post->ID, '_my_meta_value_key', true );
        
        echo '<label for="character_id_field">';
        _e( 'ID', 'text-domain' );
        echo '</label> ';
        echo '<input type="text" id="character_id_field" name="character_id_field" value="' . esc_attr( $value ) . '" size="25" />';
        }
        
        /**
         * When the post is saved, saves our custom data.
         *
         * @param int $post_id The ID of the post being saved.
         */
         function character_save_meta_box_data( $post_id ) {
        
         if ( ! isset( $_POST['character_meta_box_nonce'] ) ) {
            return;
         }
        
         if ( ! wp_verify_nonce( $_POST['character_meta_box_nonce'], 'character_save_meta_box_data' ) ) {
            return;
         }
        
         if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
            return;
         }
        
         // Check the user's permissions.
         if ( isset( $_POST['post_type'] ) && 'page' == $_POST['post_type'] ) {
        
            if ( ! current_user_can( 'edit_page', $post_id ) ) {
                return;
            }
        
         } else {
        
            if ( ! current_user_can( 'edit_post', $post_id ) ) {
                return;
            }
         }
        
         if ( ! isset( $_POST['character_id_field'] ) ) {
            return;
         }
        
         $my_data = sanitize_text_field( $_POST['character_id_field'] );
        
         update_post_meta( $post_id, '_my_meta_value_key', $my_data );
        }
        add_action( 'save_post', 'character_save_meta_box_data' );
//custom fields end

//update data from api
function update_api_data( $post_id, $post  ) {

    // echo $post_id; 
    echo '<pre>';
    $response  = wp_remote_request('https://thronesapi.com/api/v2/Characters/');

    $body = wp_remote_retrieve_body($response); 
    // print_r($_POST);
    // print_r(json_decode ( $body));
    $posts_data = json_decode ( $body);
    if(!empty($posts_data)){ 
        foreach ($posts_data as $key => $val) {
            if ($val->id == $_POST['character_id_field']) {
                // echo $key;
                $_POST['post_title'] = $posts_data[$key]->fullName;
                // print_r($posts_data[$key]);
                $img = wp_get_attachment_image_src( $_POST['featured_media'] );
                // echo $posts_data[$key]->imageUrl;



                // Add Featured Image to Post
                $image_url        = $posts_data[$key]->imageUrl; // Define the image URL here
                $image_name       = $posts_data[$key]->image;
                $upload_dir       = wp_upload_dir(); // Set upload folder
                $image_data       = file_get_contents($image_url); // Get image data
                $unique_file_name = wp_unique_filename( $upload_dir['path'], $image_name ); // Generate unique name
                $filename         = basename( $unique_file_name ); // Create image file name

                // Check folder permission and define file location
                if( wp_mkdir_p( $upload_dir['path'] ) ) {
                    $file = $upload_dir['path'] . '/' . $filename;
                } else {
                    $file = $upload_dir['basedir'] . '/' . $filename;
                }

                // Create the image  file on the server
                file_put_contents( $file, $image_data );

                // Check image file type
                $wp_filetype = wp_check_filetype( $filename, null );

                // Set attachment data
                $attachment = array(
                    'post_mime_type' => $wp_filetype['type'],
                    'post_title'     => sanitize_file_name( $filename ),
                    'post_content'   => '',
                    'post_status'    => 'inherit'
                );

                // Create the attachment
                $attach_id = wp_insert_attachment( $attachment, $file, $post_id );

                // Include image.php
                require_once(ABSPATH . 'wp-admin/includes/image.php');

                // Define attachment metadata
                $attach_data = wp_generate_attachment_metadata( $attach_id, $file );

                // Assign metadata to attachment
                wp_update_attachment_metadata( $attach_id, $attach_data );

                // And finally assign featured image to post
                set_post_thumbnail( $post_id, $attach_id );


                $my_post = array(
                    'post_title'   => $posts_data[$key]->fullName,
                );
                
                // Update the post into the database
                wp_update_post( $my_post );
            }
        }
    }  
    return true;
}
add_action( 'publish_characters', 'update_api_data', 10, 3 );